# The Fyers API Javascript client - v3

The official Javascript node client for communicating with the [Fyers API](https://myapi.fyers.in)

## Documentation

- [Javascript client documentation](https://myapi.fyers.in/docsv3)

## Requirements

- NodeJS v12.0.0+

## Installation

Install via [npm](...)

    npm install fyers-api-v3@latest

## Breaking changes - v3

`v3` is a **breaking** major release with multiple internal modification to improve user experience.<br>

Below are the breaking changes:

- websocket output format have changed completely

## Getting started with API

```javascript
var fyersModel= require("fyers-api-v3").fyersModel

var fyers= new fyersModel({"path":"path where you want to save logs","enableLogging":true})

fyers.setAppId("xxxxx-xxx")

fyers.setRedirectUrl("Redirect URL here")

var URL=fyers.generateAuthCode()

//use url to generate auth code
console.log(URL) 

var authcode="authcode generated above"

fyers.generate_access_token({"client_id":"APPID","secret_key":"secret","auth_code":authcode}).then((response)=>{
    if(response.s=='ok'){
        fyers.setAccessToken(response.access_token)
    }else{
        console.log("error generating access token",response)
    }
})

fyers.get_profile().then((response)=>{
        console.log(response)
    }).catch((err)=>{
        console.log(err)
    })
    
fyers.getQuotes(["NSE:SBIN-EQ","NSE:TCS-EQ"]).then((response)=>{
    console.log(response)
}).catch((err)=>{
    console.log(err)
})

fyers.getMarketDepth({"symbol":["NSE:SBIN-EQ","NSE:TCS-EQ"],"ohlcv_flag":1}).then((response)=>{
    console.log(response)
}).catch((err)=>{
    console.log(err)
})
```

## API promises

All API calls returns a promise which you can use to call methods like `.then(...)` and `.catch(...)`.

```javascript
FyersApiCall
  .then(function (v) {
    // On success
  })
  .catch(function (e) {
    // On rejected
  });
```

## Getting started order WebSocket

```javascript
var fyersOrderSocket= require("fyers-api-v3").fyersOrderSocket

var skt=new fyersOrderSocket("Acesstoken in format APPID:Accesstoken",
"path to where you want to save logs",
true/*flag to enable disable logging*/)

skt.on("error",function (errmsg) {
    console.log(errmsg)
})

skt.on('others',function (msg) {
    console.log(msg)
})

skt.on('connect',function () {
    skt.subscribe([skt.orderUpdates,skt.tradeUpdates,skt.positionUpdates,
    skt.edis,skt.pricealerts])
    console.log(skt.isConnected())
})

skt.on('close',function () {
    console.log('closed')
})

skt.on('orders',function (msg) {
    console.log("orders",msg)
    skt.close()
})

skt.on('trades',function (msg) {
    console.log('trades',msg)
})

skt.on('positions',function (msg) {
    console.log('positions',msg)
})

skt.connect()
```

## Getting started data WebSocket

```javascript
let DataSocket = require("fyers-api-v3").fyersDataSocket;

var skt= DataSocket.getInstance("Accesstoken in format APPID:AccessToken",
"path where to save logs",true/*flag to enable disable logging*/)

skt.on("connect",function(){
skt.subscribe(['NSE:IDEA-EQ',"NSE:SBIN-EQ"]) 
//subscribing for market depth data if need of market depth comes as a diffrent tick
skt.subscribe(['NSE:IDEA-EQ',"NSE:SBIN-EQ"],true) 
//to start lite mode to get fewer data like ltp change
skt.mode(skt.LiteMode) 
//to revert back to full mode
// skt.mode(skt.FullMode) 
})

skt.on("message",function(message){
	console.log({"TEST":message})
})

skt.on("error",function(message){
	console.log("erroris",message)
})

skt.on("close",function(){
    console.log("socket closed")
})
skt.connect()
```

## Auto re-connect WebSocket client

Optionally you can enable client side auto re-connection to automatically reconnect if the connection is dropped.

All you need to do is enable auto re-connection. For example

```javascript
// Enable auto reconnect mechanism with retry count as passed with max allowed upto 50.
skt.autoReconnect(6);
```


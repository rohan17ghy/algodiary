const fs = require('fs');
const JavaScriptObfuscator = require('javascript-obfuscator');

const inputFilePath = './HSM/datasocket.js';
const outputFilePath = './HSM/datasocket.min.js';

const inputFileContent = fs.readFileSync(inputFilePath, 'utf8');

const obfuscationResult = JavaScriptObfuscator.obfuscate(inputFileContent, {
    compact: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 1,
    numbersToExpressions: true,
    simplify: true,
    shuffleStringArray: true,
    splitStrings: true,
    splitStringsChunkLength: 10,
    stringArray: true,
    stringArrayThreshold: 1,
    transformObjectKeys: true, 
});

fs.writeFileSync(outputFilePath, obfuscationResult.getObfuscatedCode(), 'utf8');

console.log('Obfuscation completed.');